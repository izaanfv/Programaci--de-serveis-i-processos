using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace AppInsegura.Servicios
{
    public class RedService
    {
        // FICHA 3: ahora HTTPS (antes http://).
        private const string UrlServidor = "https://api.miapp-insegura.local/puntuaciones";

        public void EnviarPuntuacion(string nombreUsuario, int puntuacion)
        {
            // FICHA 1: la clave ya no esta escrita en el código.
            // Se lee de una variable de entorno (queda fuera del programa).
            string? apiKey = Environment.GetEnvironmentVariable("APPINSEGURA_API_KEY");
            if (string.IsNullOrEmpty(apiKey))
            {
                Console.WriteLine("No se puede sincronizar: falta la configuración.");
                return;
            }

            try
            {
                EnviarPuntuacionAsync(nombreUsuario, puntuacion, apiKey).GetAwaiter().GetResult();
            }
            catch (Exception)
            {
                // FICHA 13: mensaje genérico (antes se mostraba ex.Message).
                Console.WriteLine("No se ha podido conectar con el servidor. Inténtalo más tarde.");
            }
        }

        private async Task EnviarPuntuacionAsync(string nombreUsuario, int puntuacion, string apiKey)
        {
            using var cliente = new HttpClient();

            // FICHA 4: la clave va en una cabecera y ya no dentro de la URL.
            cliente.DefaultRequestHeaders.Add("X-Api-Key", apiKey);
            string url = $"{UrlServidor}?usuario={nombreUsuario}&puntos={puntuacion}";

            // FICHA 4: ya no se muestra la URL por pantalla.
            Console.WriteLine("Enviando puntuación...");
            HttpResponseMessage respuesta = await cliente.GetAsync(url);
            Console.WriteLine($"Respuesta del servidor: {(int)respuesta.StatusCode}");
        }
    }
}
