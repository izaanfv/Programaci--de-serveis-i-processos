using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using AppInsegura.Modelos;

namespace AppInsegura.Datos
{
    public class BaseDatosUsuarios
    {
        private readonly List<Usuario> usuarios = new List<Usuario>();

        public void Agregar(Usuario usuario)
        {
            usuarios.Add(usuario);
        }

        public List<Usuario> ListarTodos()
        {
            return usuarios;
        }

        public Usuario? BuscarExacto(string nombre)
        {
            return usuarios.FirstOrDefault(u => u.Nombre == nombre);
        }

        public Usuario? BuscarPorNombre(string nombreBuscado)
        {
            string consulta = $"SELECT * FROM usuarios WHERE nombre = '{nombreBuscado}'";
            return EjecutarConsultaSimulada(consulta);
        }

        private Usuario? EjecutarConsultaSimulada(string consulta)
        {
            if (consulta.Contains("' OR '1'='1") || consulta.Contains("' OR 1=1") || consulta.Contains("'='"))
            {
                return usuarios.FirstOrDefault();
            }

            Match coincidencia = Regex.Match(consulta, "nombre = '([^']*)'");
            if (!coincidencia.Success)
            {
                return null;
            }

            string nombre = coincidencia.Groups[1].Value;
            return usuarios.FirstOrDefault(u => u.Nombre == nombre);
        }
    }
}
